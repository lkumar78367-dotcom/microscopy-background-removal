# Efficient Background Removal for Phase Contrast and DIC Microscopy Images

Project portfolio page for an MSc Biomedical Engineering thesis, University of
Strathclyde, 2024–2025. Static site — no build step, no framework, no dependencies.

The page includes an interactive tool that runs three classical background-removal
methods on a 256×256 microscopy field of view entirely in the browser, and scores
the result with PSNR and SSIM against the reference construction from the thesis.

## Running it locally

The demo reads pixels back off a `<canvas>`. Browsers block that when a page is
opened directly from disk (`file://`), because drawing a local image taints the
canvas. **You must serve the folder over HTTP.** Any of these work:

```bash
# Python 3 — already installed on most systems
python -m http.server 8000

# Node
npx serve .

# npm script provided in package.json
npm start
```

Then open <http://localhost:8000>.

If you open `index.html` by double-clicking it, the page renders correctly but the
demo shows "serve over http" instead of metrics. That is the expected behaviour,
not a bug.

## Project structure

```
microscopy-portfolio/
├── index.html          Page markup, all 16 sections
├── css/
│   └── style.css       All styling. Light and dark themes via CSS custom properties.
├── js/
│   └── demo.js         The interactive tool (see below)
├── assets/
│   ├── sample.jpg              Default demo input — 512×512 crop of thesis Figure 2
│   ├── fig-problem.jpg         Thesis Figure 1 — original vs background corrected
│   ├── fig-rolling-ball.jpg    Thesis Figure 2 — rolling ball result
│   ├── fig-morphological.jpg   Thesis Figure 3 — opening and closing
│   └── fig-unet.jpg            Thesis Figure 4 — input and U-Net foreground mask
├── package.json        Local server script only. No dependencies to install.
├── .nojekyll           Stops GitHub Pages running the site through Jekyll
└── LICENSE             MIT
```

## What `js/demo.js` implements

Everything runs at 256×256 on a `<canvas>`, in plain JavaScript, with no libraries:

| Function | What it does |
|---|---|
| `sep` / `erode` / `dilate` / `opening` | Grayscale morphology via separable 1-D min/max passes |
| `polySurface` | 3rd-order 2D polynomial surface fit, least squares by normal equations with partial-pivot Gaussian elimination |
| `histMatch` | Histogram matching by rank order |
| `fft1` / `fft2` / `butterworth` | In-place radix-2 FFT and a 2nd-order Butterworth high-pass |
| `buildReference` | The thesis §2.5.1 reference construction: opening → polynomial surface → subtract → histogram match |
| `psnr` / `ssim` | PSNR, and SSIM with an 11×11 Gaussian window, K₁=0.01, K₂=0.03, L=1 |

Method parameters come from the thesis parameter study. The rolling ball uses a
separable square structuring element rather than a disk, so it runs at interactive
speed; the background estimate is smoothed before subtraction. This is noted on the
page itself.

**The U-Net does not run here.** The trained weights were not published with the
project, so its recorded output is shown as a figure rather than computed live. The
metrics the tool reports are computed on the single displayed image and are not the
thesis results, which were measured on a held-out test set.

## Deploying to GitHub Pages

1. Push this folder to a repository.
2. Settings → Pages → Source: *Deploy from a branch*.
3. Branch `main`, folder `/ (root)` if this is the repo root, or `/docs` if you put
   it there.
4. `.nojekyll` is already present, so Jekyll will not touch the files.

Served over HTTPS, so the demo works.

## Browser support

Needs `canvas`, `FileReader`, `Float32Array` and `Float64Array` — every current
browser. No polyfills, no transpilation.

## Notes on the content

All figures are extracted from the thesis PDF and are unmodified apart from resizing
and JPEG compression. All quantitative results on the page are those reported in the
thesis. Fonts load from Google Fonts; without a network connection the page falls
back to Georgia and the system sans-serif and remains fully readable.

## Links

- Code: https://github.com/lokesh-rajagopal/microscopy-background-removal
- LinkedIn: https://linkedin.com/in/lokesh29

## Licence

MIT — see LICENSE.
